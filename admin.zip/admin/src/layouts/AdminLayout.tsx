import { useState } from 'react';
import { Layout, Menu, Button, Avatar, Dropdown } from 'antd';
import {
  DashboardOutlined,
  TeamOutlined,
  FundOutlined,
  CloudOutlined,
  BellOutlined,
  MessageOutlined,
  LogoutOutlined,
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  UserOutlined,
} from '@ant-design/icons';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { useAdminStore } from '../store/adminStore';

const { Header, Sider, Content } = Layout;

const menuItems = [
  { key: '/dashboard', icon: <DashboardOutlined />, label: '仪表盘' },
  { key: '/users', icon: <TeamOutlined />, label: '用户管理' },
  { key: '/funds', icon: <FundOutlined />, label: '基金管理' },
  { key: '/announcements', icon: <BellOutlined />, label: '公告管理' },
  { key: '/feedbacks', icon: <MessageOutlined />, label: '意见反馈' },
  { key: '/cache', icon: <CloudOutlined />, label: '缓存检测' },
];

export default function AdminLayout() {
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout } = useAdminStore();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const userMenuItems = [
    { key: 'logout', icon: <LogoutOutlined />, label: '退出登录', onClick: handleLogout },
  ];

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Sider
        collapsible
        collapsed={collapsed}
        onCollapse={setCollapsed}
        width={220}
        style={{
          background: '#0D1117',
          borderRight: '1px solid #30363D',
        }}
        theme="dark"
      >
        <div style={{
          height: 64,
          display: 'flex',
          alignItems: 'center',
          justifyContent: collapsed ? 'center' : 'flex-start',
          padding: collapsed ? '0' : '0 20px',
          borderBottom: '1px solid #30363D',
        }}>
          <span style={{
            fontSize: collapsed ? 18 : 20,
            fontWeight: 700,
            background: 'linear-gradient(135deg, #D4A84B, #F0D78C)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
          }}>
            {collapsed ? '养' : '养基发财'}
          </span>
          {!collapsed && (
            <span style={{
              fontSize: 11,
              color: '#8B949E',
              marginLeft: 10,
              background: 'rgba(212,168,75,0.15)',
              padding: '2px 8px',
              borderRadius: 4,
            }}>
              管理后台
            </span>
          )}
        </div>
        <Menu
          mode="inline"
          selectedKeys={[location.pathname]}
          items={menuItems}
          onClick={({ key }) => navigate(key)}
          style={{
            background: 'transparent',
            borderRight: 'none',
            marginTop: 8,
          }}
          theme="dark"
        />
        {!collapsed && (
          <div style={{
            position: 'absolute',
            bottom: 0,
            left: 0,
            right: 0,
            padding: '16px 20px',
            borderTop: '1px solid #30363D',
            display: 'flex',
            alignItems: 'center',
            gap: 10,
          }}>
            <Avatar size={32} icon={<UserOutlined />} style={{ background: '#D4A84B' }} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 13, color: '#E6EDF3', fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user?.username}</div>
              <div style={{ fontSize: 11, color: '#8B949E' }}>管理员</div>
            </div>
            <Button type="text" icon={<LogoutOutlined />} size="small" onClick={handleLogout} style={{ color: '#8B949E' }} />
          </div>
        )}
      </Sider>
      <Layout>
        <Header style={{
          padding: '0 24px',
          background: '#161B22',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          borderBottom: '1px solid #30363D',
          height: 56,
        }}>
          <Button
            type="text"
            icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
            onClick={() => setCollapsed(!collapsed)}
            style={{ color: '#8B949E', fontSize: 16 }}
          />
          <Dropdown menu={{ items: userMenuItems }} placement="bottomRight">
            <div style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8 }}>
              <Avatar size={28} icon={<UserOutlined />} style={{ background: '#D4A84B' }} />
              <span style={{ color: '#E6EDF3', fontSize: 13 }}>{user?.username}</span>
            </div>
          </Dropdown>
        </Header>
        <Content style={{ margin: 24, minHeight: 280 }}>
          <Outlet />
        </Content>
      </Layout>
    </Layout>
  );
}
