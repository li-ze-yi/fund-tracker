import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ConfigProvider, App as AntApp, Spin, theme as antTheme } from 'antd';
import zhCN from 'antd/locale/zh_CN';
import { useEffect } from 'react';
import { useAdminStore } from './store/adminStore';
import AdminLayout from './layouts/AdminLayout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Users from './pages/Users';
import Funds from './pages/Funds';
import Cache from './pages/Cache';
import Announcements from './pages/Announcements';
import Feedbacks from './pages/Feedbacks';
import './App.css';

function AdminRoute({ children }: { children: React.ReactNode }) {
  const { user, isInitialized } = useAdminStore();
  if (!isInitialized) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <Spin size="large" />
      </div>
    );
  }
  if (!user || user.role !== 'admin') return <Navigate to="/login" replace />;
  return <>{children}</>;
}

export default function App() {
  const restoreSession = useAdminStore((s) => s.restoreSession);
  const isInitialized = useAdminStore((s) => s.isInitialized);

  useEffect(() => {
    restoreSession();
  }, [restoreSession]);

  if (!isInitialized) {
    return (
      <ConfigProvider locale={zhCN} theme={{ algorithm: antTheme.darkAlgorithm, token: { colorPrimary: '#D4A84B', borderRadius: 6 } }}>
        <AntApp>
          <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
            <Spin size="large" />
          </div>
        </AntApp>
      </ConfigProvider>
    );
  }

  return (
    <ConfigProvider
      locale={zhCN}
      theme={{
        algorithm: antTheme.darkAlgorithm,
        token: {
          colorPrimary: '#D4A84B',
          borderRadius: 6,
          colorBgContainer: '#161B22',
          colorBgElevated: '#1C2128',
          colorBgLayout: '#0D1117',
          colorBorder: '#30363D',
          colorText: '#E6EDF3',
          colorTextSecondary: '#8B949E',
        },
      }}
    >
      <AntApp>
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route
              element={
                <AdminRoute>
                  <AdminLayout />
                </AdminRoute>
              }
            >
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/users" element={<Users />} />
              <Route path="/funds" element={<Funds />} />
              <Route path="/announcements" element={<Announcements />} />
              <Route path="/feedbacks" element={<Feedbacks />} />
              <Route path="/cache" element={<Cache />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </AntApp>
    </ConfigProvider>
  );
}
