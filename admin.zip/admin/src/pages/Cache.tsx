import { useEffect, useState, useCallback } from 'react';
import { Table, Button, Input, Tag, Row, Col, Progress, App, Space, Statistic, Tooltip } from 'antd';
import {
  SearchOutlined,
  ReloadOutlined,
  DeleteOutlined,
  CloudOutlined,
  CheckCircleOutlined,
  CloseCircleOutlined,
  ThunderboltOutlined,
} from '@ant-design/icons';
import { adminApi } from '../api';

interface CacheEntry {
  key: string;
  type: string;
  ageSeconds: number;
  ttlSeconds: number;
  remainingSeconds: number;
  expired: boolean;
}

interface CacheStats {
  hits: number;
  misses: number;
  evictions: number;
  totalRequests: number;
  hitRate: string;
  size: number;
  maxSize: number;
  tradingStatus: string;
  realtimeTTL: string;
}

interface CacheData {
  stats: CacheStats;
  entries: CacheEntry[];
}

interface CheckResult {
  hit: boolean;
  key: string;
  type?: string;
  ageSeconds?: number;
  ttlSeconds?: number;
  remainingSeconds?: number;
  expired?: boolean;
}

const statusMap: Record<string, { label: string; color: string }> = {
  trading: { label: '交易中', color: '#43A047' },
  after_hours: { label: '盘后', color: '#FB8C00' },
  pre_market: { label: '盘前', color: '#1E88E5' },
  weekend: { label: '周末', color: '#8E24AA' },
};

const typeColorMap: Record<string, string> = {
  realtime: '#E53935',
  history_recent: '#FB8C00',
  history_older: '#43A047',
  fund_info: '#1E88E5',
  fund_list: '#8E24AA',
  market_status: '#00ACC1',
};

export default function Cache() {
  const { modal } = App.useApp();
  const [data, setData] = useState<CacheData | null>(null);
  const [loading, setLoading] = useState(true);
  const [checkKey, setCheckKey] = useState('');
  const [checkResult, setCheckResult] = useState<CheckResult | null>(null);
  const [checkLoading, setCheckLoading] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const res = await adminApi.cacheStats();
      setData(res);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleCheck = async () => {
    if (!checkKey.trim()) return;
    setCheckLoading(true);
    try {
      const res = await adminApi.cacheCheck(checkKey.trim());
      setCheckResult(res);
    } finally {
      setCheckLoading(false);
    }
  };

  const handleClearAll = () => {
    modal.confirm({
      title: '确认清空全部缓存',
      content: '清空缓存后，所有用户的请求将直接访问外部API，可能导致短暂响应变慢。确定要清空吗？',
      okText: '确认清空',
      cancelText: '取消',
      okType: 'danger',
      onOk: async () => {
        await adminApi.cacheClear();
        setCheckResult(null);
        loadData();
      },
    });
  };

  const handleClearOne = (key: string) => {
    modal.confirm({
      title: '确认清除缓存',
      content: `确定要清除缓存 "${key}" 吗？`,
      okText: '确认',
      cancelText: '取消',
      onOk: async () => {
        await adminApi.cacheClear(key);
        loadData();
      },
    });
  };

  if (!data) return null;

  const stats = data.stats;
  const hitRateNum = parseFloat(stats.hitRate);
  const statusInfo = statusMap[stats.tradingStatus] || { label: stats.tradingStatus, color: '#8B949E' };

  const columns = [
    {
      title: '缓存Key',
      dataIndex: 'key',
      ellipsis: { showTitle: false },
      render: (v: string) => (
        <Tooltip placement="topLeft" title={v}>
          <span style={{ fontFamily: 'monospace', fontSize: 12, color: '#E6EDF3' }}>{v}</span>
        </Tooltip>
      ),
    },
    {
      title: '类型',
      dataIndex: 'type',
      width: 120,
      render: (v: string) => (
        <Tag color={typeColorMap[v] || '#8B949E'} style={{ borderRadius: 4, fontSize: 11 }}>
          {v}
        </Tag>
      ),
    },
    {
      title: '已存活',
      dataIndex: 'ageSeconds',
      width: 80,
      render: (v: number) => <span style={{ fontVariantNumeric: 'tabular-nums' }}>{v}s</span>,
    },
    {
      title: 'TTL',
      dataIndex: 'ttlSeconds',
      width: 80,
      render: (v: number) => <span style={{ fontVariantNumeric: 'tabular-nums' }}>{v}s</span>,
    },
    {
      title: '剩余时间',
      key: 'remaining',
      width: 160,
      render: (_: unknown, record: CacheEntry) => (
        <Progress
          percent={Math.round((record.remainingSeconds / record.ttlSeconds) * 100)}
          format={() => `${record.remainingSeconds}s`}
          strokeColor={record.remainingSeconds < record.ttlSeconds * 0.2 ? '#E53935' : '#D4A84B'}
          trailColor="rgba(212,168,75,0.1)"
          size="small"
        />
      ),
    },
    {
      title: '状态',
      dataIndex: 'expired',
      width: 70,
      render: (v: boolean) => v
        ? <Tag color="error" style={{ borderRadius: 4 }}>过期</Tag>
        : <Tag color="success" style={{ borderRadius: 4 }}>有效</Tag>,
    },
    {
      title: '操作',
      key: 'action',
      width: 80,
      render: (_: unknown, record: CacheEntry) => (
        <Button
          type="text"
          danger
          size="small"
          icon={<DeleteOutlined />}
          onClick={() => handleClearOne(record.key)}
        />
      ),
    },
  ];

  return (
    <div>
      <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 24, color: '#E6EDF3' }}>缓存命中检测</h2>

      <Row gutter={[16, 16]}>
        <Col xs={24} sm={12} lg={6}>
          <div className="stat-card">
            <Statistic
              title={<span style={{ color: '#8B949E' }}>命中率</span>}
              value={hitRateNum}
              suffix="%"
              valueStyle={{ color: hitRateNum >= 80 ? '#43A047' : hitRateNum >= 50 ? '#FB8C00' : '#E53935', fontWeight: 700 }}
              prefix={<ThunderboltOutlined />}
            />
            <Progress
              percent={hitRateNum}
              showInfo={false}
              strokeColor={hitRateNum >= 80 ? '#43A047' : hitRateNum >= 50 ? '#FB8C00' : '#E53935'}
              trailColor="rgba(212,168,75,0.1)"
              size="small"
              style={{ marginTop: 8 }}
            />
          </div>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <div className="stat-card">
            <Statistic
              title={<span style={{ color: '#8B949E' }}>命中 / 未命中</span>}
              value={stats.hits}
              suffix={` / ${stats.misses}`}
              valueStyle={{ color: '#E6EDF3', fontWeight: 700 }}
              prefix={<CheckCircleOutlined style={{ color: '#43A047' }} />}
            />
            <div style={{ marginTop: 8, fontSize: 12, color: '#8B949E' }}>
              总请求: {stats.totalRequests.toLocaleString()}
            </div>
          </div>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <div className="stat-card">
            <Statistic
              title={<span style={{ color: '#8B949E' }}>缓存条目</span>}
              value={stats.size}
              suffix={`/ ${stats.maxSize}`}
              valueStyle={{ color: '#D4A84B', fontWeight: 700 }}
              prefix={<CloudOutlined />}
            />
            <div style={{ marginTop: 8, fontSize: 12, color: '#8B949E' }}>
              过期清理: {stats.evictions}
            </div>
          </div>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <div className="stat-card">
            <Statistic
              title={<span style={{ color: '#8B949E' }}>交易状态</span>}
              value={statusInfo.label}
              valueStyle={{ color: statusInfo.color, fontWeight: 700 }}
            />
            <div style={{ marginTop: 8, fontSize: 12, color: '#8B949E' }}>
              实时估值TTL: {stats.realtimeTTL}
            </div>
          </div>
        </Col>
      </Row>

      <div style={{ marginTop: 24 }}>
        <div style={{
          background: '#161B22',
          border: '1px solid #30363D',
          borderRadius: 10,
          padding: 20,
        }}>
          <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 16, color: '#E6EDF3' }}>
            🔍 缓存Key检测
          </h3>
          <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
            <Input
              placeholder="输入缓存Key进行检测，如 realtime_110011"
              prefix={<SearchOutlined style={{ color: '#6E7681' }} />}
              value={checkKey}
              onChange={(e) => setCheckKey(e.target.value)}
              onPressEnter={handleCheck}
              style={{ flex: 1, background: '#21262D', borderColor: '#30363D' }}
            />
            <Button
              type="primary"
              icon={<SearchOutlined />}
              onClick={handleCheck}
              loading={checkLoading}
            >
              检测
            </Button>
          </div>
          {checkResult && (
            <div style={{
              background: checkResult.hit ? 'rgba(67,160,71,0.08)' : 'rgba(229,57,53,0.08)',
              border: `1px solid ${checkResult.hit ? 'rgba(67,160,71,0.3)' : 'rgba(229,57,53,0.3)'}`,
              borderRadius: 8,
              padding: 16,
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                {checkResult.hit
                  ? <CheckCircleOutlined style={{ color: '#43A047', fontSize: 18 }} />
                  : <CloseCircleOutlined style={{ color: '#E53935', fontSize: 18 }} />
                }
                <span style={{ fontWeight: 600, color: checkResult.hit ? '#43A047' : '#E53935' }}>
                  {checkResult.hit ? '缓存命中' : '缓存未命中'}
                </span>
                <Tag style={{ fontFamily: 'monospace', fontSize: 11, background: 'rgba(212,168,75,0.1)', borderColor: 'rgba(212,168,75,0.3)', color: '#F0D78C', borderRadius: 4 }}>
                  {checkResult.key}
                </Tag>
              </div>
              {checkResult.hit && (
                <Row gutter={16}>
                  <Col span={6}>
                    <div style={{ fontSize: 12, color: '#8B949E' }}>类型</div>
                    <Tag color={typeColorMap[checkResult.type || ''] || '#8B949E'} style={{ borderRadius: 4, marginTop: 4 }}>
                      {checkResult.type}
                    </Tag>
                  </Col>
                  <Col span={6}>
                    <div style={{ fontSize: 12, color: '#8B949E' }}>已存活</div>
                    <div style={{ fontWeight: 600, color: '#E6EDF3', marginTop: 4 }}>{checkResult.ageSeconds}s</div>
                  </Col>
                  <Col span={6}>
                    <div style={{ fontSize: 12, color: '#8B949E' }}>TTL</div>
                    <div style={{ fontWeight: 600, color: '#E6EDF3', marginTop: 4 }}>{checkResult.ttlSeconds}s</div>
                  </Col>
                  <Col span={6}>
                    <div style={{ fontSize: 12, color: '#8B949E' }}>剩余</div>
                    <div style={{ fontWeight: 600, color: checkResult.expired ? '#E53935' : '#43A047', marginTop: 4 }}>
                      {checkResult.remainingSeconds}s {checkResult.expired ? '(已过期)' : ''}
                    </div>
                  </Col>
                </Row>
              )}
            </div>
          )}
        </div>
      </div>

      <div style={{ marginTop: 24 }}>
        <div style={{
          background: '#161B22',
          border: '1px solid #30363D',
          borderRadius: 10,
          padding: 20,
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <h3 style={{ fontSize: 15, fontWeight: 600, color: '#E6EDF3', margin: 0 }}>
              缓存条目列表 ({data.entries.length})
            </h3>
            <Space>
              <Button
                icon={<ReloadOutlined />}
                onClick={loadData}
                loading={loading}
              >
                刷新
              </Button>
              <Button
                danger
                icon={<DeleteOutlined />}
                onClick={handleClearAll}
              >
                清空全部
              </Button>
            </Space>
          </div>
          <Table
            columns={columns}
            dataSource={data.entries}
            rowKey="key"
            loading={loading}
            pagination={{ pageSize: 20, showTotal: (t) => `共 ${t} 条` }}
            size="small"
            style={{ background: 'transparent' }}
          />
        </div>
      </div>
    </div>
  );
}
