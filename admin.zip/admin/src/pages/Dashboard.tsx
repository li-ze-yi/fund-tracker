import { useEffect, useState } from 'react';
import { Row, Col, Spin, Table, Tag, Progress } from 'antd';
import {
  UserOutlined,
  FundOutlined,
  SwapOutlined,
  PieChartOutlined,
} from '@ant-design/icons';
import { adminApi } from '../api';

interface HoldingUserItem {
  fund_code: string;
  fund_name: string;
  user_count: number;
}

interface DashboardData {
  userStats: { total: number; todayNew: number; activeCount: number };
  fundStats: { total: number; byType: { type: string; count: number }[] };
  transactionStats: { total: number; buyCount: number; sellCount: number; totalAmount: number };
  holdingStats: { total: number; avgPerUser: number };
  holdingUserStats: HoldingUserItem[];
}

export default function Dashboard() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    adminApi.dashboard().then(setData).finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', padding: 80 }}>
        <Spin size="large" />
      </div>
    );
  }

  if (!data) return null;

  const holdingUserStats = data.holdingUserStats || [];
  const maxUserCount = holdingUserStats.length > 0 ? holdingUserStats[0].user_count : 1;

  const cards = [
    {
      label: '用户总数',
      value: data.userStats.total,
      sub: `今日新增 ${data.userStats.todayNew} · 7日活跃 ${data.userStats.activeCount}`,
      icon: <UserOutlined style={{ fontSize: 20, color: '#D4A84B' }} />,
    },
    {
      label: '基金总数',
      value: data.fundStats.total,
      sub: `${data.fundStats.byType.slice(0, 3).map((t) => `${t.type} ${t.count}`).join(' · ')}`,
      icon: <FundOutlined style={{ fontSize: 20, color: '#D4A84B' }} />,
    },
    {
      label: '交易总数',
      value: data.transactionStats.total,
      sub: `买入 ${data.transactionStats.buyCount} · 卖出 ${data.transactionStats.sellCount}`,
      icon: <SwapOutlined style={{ fontSize: 20, color: '#D4A84B' }} />,
    },
    {
      label: '持仓记录',
      value: data.holdingStats.total,
      sub: `人均持仓 ${data.holdingStats.avgPerUser.toFixed(1)} 只基金`,
      icon: <PieChartOutlined style={{ fontSize: 20, color: '#D4A84B' }} />,
    },
  ];

  const holdingColumns = [
    {
      title: '排名',
      key: 'rank',
      width: 60,
      render: (_: unknown, __: unknown, index: number) => (
        <span style={{
          display: 'inline-flex',
          alignItems: 'center',
          justifyContent: 'center',
          width: 24,
          height: 24,
          borderRadius: 6,
          fontSize: 12,
          fontWeight: 700,
          background: index < 3 ? 'linear-gradient(135deg, #D4A84B, #B8922E)' : 'rgba(139,148,158,0.15)',
          color: index < 3 ? '#0D1117' : '#8B949E',
        }}>
          {index + 1}
        </span>
      ),
    },
    {
      title: '基金代码',
      dataIndex: 'fund_code',
      width: 110,
      render: (v: string) => <Tag style={{ background: 'rgba(212,168,75,0.1)', borderColor: 'rgba(212,168,75,0.3)', color: '#F0D78C', borderRadius: 4 }}>{v}</Tag>,
    },
    {
      title: '基金名称',
      dataIndex: 'fund_name',
      ellipsis: true,
    },
    {
      title: '持仓用户数',
      dataIndex: 'user_count',
      width: 120,
      sorter: (a: HoldingUserItem, b: HoldingUserItem) => a.user_count - b.user_count,
      render: (v: number) => <span style={{ fontWeight: 600, color: '#D4A84B', fontVariantNumeric: 'tabular-nums' }}>{v}</span>,
    },
    {
      title: '占比',
      key: 'bar',
      width: 200,
      render: (_: unknown, record: HoldingUserItem) => (
        <Progress
          percent={Math.round((record.user_count / maxUserCount) * 100)}
          showInfo={false}
          strokeColor="#D4A84B"
          trailColor="rgba(212,168,75,0.1)"
          size="small"
        />
      ),
    },
  ];

  return (
    <div>
      <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 24, color: '#E6EDF3' }}>仪表盘</h2>
      <Row gutter={[20, 20]}>
        {cards.map((card) => (
          <Col xs={24} sm={12} lg={6} key={card.label}>
            <div className="stat-card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <div className="stat-label">{card.label}</div>
                  <div className="stat-value">{card.value.toLocaleString()}</div>
                  <div className="stat-sub">{card.sub}</div>
                </div>
                <div style={{
                  width: 40,
                  height: 40,
                  borderRadius: 10,
                  background: 'rgba(212,168,75,0.1)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                  {card.icon}
                </div>
              </div>
            </div>
          </Col>
        ))}
      </Row>

      <div style={{ marginTop: 32 }}>
        <h3 style={{ fontSize: 16, fontWeight: 600, marginBottom: 16, color: '#E6EDF3' }}>基金持仓用户统计 TOP 20</h3>
        <div style={{
          background: '#161B22',
          border: '1px solid #30363D',
          borderRadius: 10,
          padding: 20,
        }}>
          <Table
            columns={holdingColumns}
            dataSource={holdingUserStats}
            rowKey="fund_code"
            pagination={false}
            size="small"
            style={{ background: 'transparent' }}
          />
        </div>
      </div>

      <div style={{ marginTop: 32 }}>
        <h3 style={{ fontSize: 16, fontWeight: 600, marginBottom: 16, color: '#E6EDF3' }}>交易金额统计</h3>
        <div className="stat-card">
          <div style={{ display: 'flex', gap: 48 }}>
            <div>
              <div className="stat-label">总交易金额</div>
              <div className="stat-value" style={{ fontSize: 24 }}>
                ¥{data.transactionStats.totalAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
            </div>
            <div>
              <div className="stat-label">买入笔数</div>
              <div style={{ fontSize: 20, fontWeight: 600, color: '#E53935' }}>{data.transactionStats.buyCount}</div>
            </div>
            <div>
              <div className="stat-label">卖出笔数</div>
              <div style={{ fontSize: 20, fontWeight: 600, color: '#43A047' }}>{data.transactionStats.sellCount}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
